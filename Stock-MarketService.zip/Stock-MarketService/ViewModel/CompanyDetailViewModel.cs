﻿namespace Stock_MarketService.ViewModel
{
    public class CompanyDetailViewModel
    {
        public string Code { get; set; }
        public string Name { get; set; }
        public string Ceo { get; set; }
        public string Website { get; set; }
        public string StockExchange { get; set; }
        public int Turnover { get; set; }
    }
}
