﻿using Stock_MarketService.Model;

namespace Stock_MarketService.Repositroy
{
    public class CompanyRepository : ICompanyRepository
    {
        public bool RegisterCompany(CompanyDetail model)
        {
            return true;
        }
    }
}
