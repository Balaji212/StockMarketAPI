﻿using Stock_MarketService.Model;

namespace Stock_MarketService.Repositroy
{
    public interface ICompanyRepository
    {
        bool RegisterCompany(CompanyDetail model);
    }
}
