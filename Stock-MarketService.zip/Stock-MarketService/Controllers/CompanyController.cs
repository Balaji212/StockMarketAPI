﻿using Microsoft.AspNetCore.Mvc;
using Stock_MarketService.Service;
using Stock_MarketService.ViewModel;
using System.Net;

namespace Stock_MarketService.Controllers
{
    [Route("api/Stock-Market/[controller]")]
    [ApiController]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService sevrice;
        public CompanyController(ICompanyService sevrice)
        {
            this.sevrice = sevrice;
        }

        [Route("Register")]
        [HttpPost]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult RegisterCompany([FromBody] CompanyDetailViewModel companyDetail)
        {
            if (companyDetail != null)
            {
                bool result = this.sevrice.RegisterCompany(companyDetail);
                if (result)
                {
                    return this.Ok();
                }
                else
                {
                    return this.BadRequest("Error occured please try again");
                }
            }
            return this.BadRequest("Invalid input please check the entered values");
        }
    }
}
