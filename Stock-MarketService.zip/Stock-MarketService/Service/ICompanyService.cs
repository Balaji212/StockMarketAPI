﻿using Stock_MarketService.ViewModel;

namespace Stock_MarketService.Service
{
    public interface ICompanyService
    {
        bool RegisterCompany(CompanyDetailViewModel model);
    }
}
