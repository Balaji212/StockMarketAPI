﻿using Stock_MarketService.Repositroy;
using Stock_MarketService.ViewModel;

namespace Stock_MarketService.Service
{
    public class CompanyService : ICompanyService
    {
        private ICompanyRepository repository;

        public CompanyService(ICompanyRepository repository)
        {
            this.repository = repository;
        }

        public bool RegisterCompany(CompanyDetailViewModel model)
        {
            return true;
        }
    }
}
