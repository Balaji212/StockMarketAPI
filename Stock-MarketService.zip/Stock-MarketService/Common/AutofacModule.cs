﻿using Autofac;
using Microsoft.Extensions.Configuration;
using Stock_MarketService.Repositroy;
using Stock_MarketService.Service;

namespace Stock_MarketService.Common
{
    public class AutofacModule : Module
    {
        private readonly IConfiguration configuration;
        public AutofacModule(IConfiguration configuration)
        {
            this.configuration = configuration;
        }

        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<CompanyService>().As<ICompanyService>();
            builder.RegisterType<CompanyRepository>().As<ICompanyRepository>();
        }
    }
}
