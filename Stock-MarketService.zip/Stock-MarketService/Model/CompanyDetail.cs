﻿namespace Stock_MarketService.Model
{
    public class CompanyDetail
    {
        public string CODE { get; set; }
        public string NAME { get; set; }
        public string CEO { get; set; }
        public string WEBSITE { get; set; }
        public string STOCK_EXCHANGE { get; set; }
        public int TURN_OVER { get; set; }
    }
}
